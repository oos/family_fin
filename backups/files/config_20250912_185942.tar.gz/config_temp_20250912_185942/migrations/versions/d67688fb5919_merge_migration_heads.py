"""Merge migration heads

Revision ID: d67688fb5919
Revises: 1f93d4586636
Create Date: 2025-09-11 22:27:56.506131

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd67688fb5919'
down_revision = '1f93d4586636'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
